// Function to update the displayed image based on the selected topic
function updateImage() {
    // Get the selected topic from the dropdown
     var selectedTopic = document.getElementById("topicDropdown");
     var selectedValue = selectedTopic.options[selectedTopic.selectedIndex].value;
     var img = document.getElementById("img");
     var img2 = document.getElementById("img2");


     if (selectedValue == "Rock") {
          img.src = "maps/rock_a.png";
          img2.src = "maps/rock_b.png";
     } else if (selectedValue == "Pop") {
          img.src = "maps/pop_a.png";
          img2.src = "maps/pop_b.png";
     } else if (selectedValue == "Country") {
          img.src = "maps/country_a.png";
          img2.src = "maps/country_b.png";
     } else if (selectedValue == "R&B") {
          img.src = "maps/r&b_a.png";
          img2.src = "maps/r&b_b.png";
     } else if (selectedValue == "HipHop") {
          img.src = "maps/hip_hop_a.png";
          img2.src = "maps/hip_hop_b.png";
     } else if (selectedValue == "Swing") {
          img.src = "maps/swing_a.png";
          img2.src = "maps/swing_b.png";
     } else if (selectedValue == "Soul") {
          img.src = "maps/soul_a.png";
          img2.src = "maps/soul_b.png";
     } else if (selectedValue == "Folk") {
          img.src = "maps/folk_a.png";
          img2.src = "maps/folk_b.png";
     } else if (selectedValue == "HeavyMetal") {
          img.src = "maps/heavy_metal_a.png";
          img2.src = "maps/heavy_metal_b.png";
     } else if (selectedValue == "Classical") {
          img.src = "maps/classical_a.png";
          img2.src = "maps/classical_b.png";
     } else if (selectedValue == "default") {
          img.src = "";
          img2.src = "";
     }
}